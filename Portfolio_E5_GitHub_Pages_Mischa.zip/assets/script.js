/* Navigation, filtres, thème et animations — sans dépendance externe. */
(function () {
  'use strict';
  const body = document.body;
  const menuButton = document.getElementById('menuButton');
  const menu = document.getElementById('menu');
  const themeButton = document.getElementById('themeButton');
  const filters = [...document.querySelectorAll('[data-filter]')];
  const projects = [...document.querySelectorAll('[data-category]')];
  const saved = (() => { try { return localStorage.getItem('portfolio-theme'); } catch(e) { return null; } })();
  if (saved === 'light') body.classList.add('theme-light');
  function toggleMenu(force) {
    const open = typeof force === 'boolean' ? force : !menu.classList.contains('is-open');
    menu.classList.toggle('is-open', open);
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  }
  menuButton.addEventListener('click', () => toggleMenu());
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => toggleMenu(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });
  themeButton.addEventListener('click', () => {
    body.classList.toggle('theme-light');
    try { localStorage.setItem('portfolio-theme', body.classList.contains('theme-light') ? 'light' : 'dark'); } catch(e) {}
  });
  filters.forEach(button => button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filters.forEach(f => { f.classList.toggle('active', f === button); f.setAttribute('aria-pressed', String(f === button)); });
    projects.forEach(project => project.classList.toggle('is-hidden', filter !== 'all' && project.dataset.category !== filter));
  }));
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    body.classList.add('js-reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); } });
    }, {threshold:.08, rootMargin:'0px 0px 50px 0px'});
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }
  const anchors = [...menu.querySelectorAll('a[href^="#"]')];
  if ('IntersectionObserver' in window) {
    const navWatcher = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) anchors.forEach(a => a.setAttribute('aria-current', a.getAttribute('href') === '#' + entry.target.id ? 'true' : 'false')); });
    }, {rootMargin:'-22% 0px -65% 0px'});
    document.querySelectorAll('main section[id]').forEach(section => navWatcher.observe(section));
  }
})();
