# Portfolio BTS SIO SISR — Mischa Maisonneuve

Site web statique prêt à être publié sur **GitHub Pages**, sans dépendance, compilation ou compte tiers autre que GitHub.

## Publier le site en ligne

1. Décompresser l'archive ZIP.
2. Aller sur [github.com/new](https://github.com/new) puis créer un dépôt public nommé par exemple `portfolio-bts-sio`.
3. Ouvrir le dépôt, choisir **Add file → Upload files** et glisser **le contenu du dossier** `portfolio_e5_github`, c'est-à-dire `index.html`, `README.md`, `.nojekyll` et `assets/` (pas le ZIP lui-même). Valider avec **Commit changes**.
4. Ouvrir **Settings → Pages** dans le dépôt.
5. Sous **Build and deployment → Source**, choisir **Deploy from a branch**. Sélectionner la branche **main** et le dossier **/(root)**, puis **Save**.
6. Une fois le déploiement terminé, le site aura une adresse du type `https://VOTRE_IDENTIFIANT.github.io/portfolio-bts-sio/`. L'adresse finale réelle est celle affichée dans **Settings → Pages**.
7. Revenir à votre tableau de synthèse **conservé en privé** et remplacer « Adresse URL du portfolio : À compléter » par cette adresse.

Référence : https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Organisation

- `index.html` : contenus, projets, compétences, sections E5.
- `assets/styles.css` : design, responsive, versions clair et sombre.
- `assets/script.js` : menu mobile, filtres, thème.
- `assets/favicon.svg` : icône du site.
- `.nojekyll` : publication statique sans traitement Jekyll.

## Personnaliser

Modifier le texte directement dans `index.html`, idéalement dans VS Code. Les 6 fiches d'entreprise correspondent à des activités déclarées par le candidat comme réalisées pendant le stage BTS 2026. Les preuves et résultats précis des activités non liées à l'audit restent à compléter avec l'enseignant.

### Avant l'oral E5

- Ajouter les dates exactes de chaque mission si demandées.
- Choisir des éléments de preuve **anonymisés** et autorisés par l'entreprise.
- Documenter des réalisations permettant d'étayer **B1.3, B1.4 et B1.6**.
- Compléter le stage de deuxième année après réalisation.
- Vérifier le tableau de synthèse officiel demandé pour la session **2027**.
- Obtenir les attestations de stage et préparer une copie hors ligne du portfolio.

## Sécurité / confidentialité

**Ne pas publier** sur GitHub les photos d'origine des baies, l'inventaire Excel interne, les noms de serveurs/switchs, les IP, les numéros de port précis, les tickets nominatifs, les comptes et droits, les adresses internes, les procédures confidentielles, les numéros de candidat ou les documents administratifs.

Le ZIP public livré ici ne contient aucun des fichiers internes. Les photographies ne sont pas incluses, même floutées, tant que la diffusion n'est pas validée.

*Ce site constitue un portfolio préparé, pas la preuve d'une validation de l'E5 par le jury.*
